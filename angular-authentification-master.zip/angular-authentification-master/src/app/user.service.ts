import { Injectable } from '@angular/core';
import { ValidUser } from './valid-user';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { User } from './user';
import { InscriptionResponse } from './inscription-response';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private validUser : ValidUser;
  private inscriptionResponse : InscriptionResponse;
  constructor(private router: Router,private http:HttpClient) { }

authenticate(user:string,pswd:string){
  const url= `${environment.serveurURL}/authenticate/${user}/${pswd}`;
  console.log(`REST vers ${url}`);
  this.http.get<ValidUser>(url)
            .subscribe(
              (data)=>{
                console.log(`${data.nom} - ${data.identifiant}- ${data.valid}`);
                if(data.valid){
                this.router.navigate(["user"]);
                }else{
                  alert("Invalid login/password");
                }
              }),
            (error)=>console.error(`ERROR ${error.message}`),
            ()=>console.log(`FIN`); 
}

subscribe(user:User){
  const url= `${environment.serveurURL}/subscribe`;
  console.log(`REST vers ${url}`);
  this.http.post<InscriptionResponse>(url,user)
            .subscribe(
              (data)=>{
                console.log(`${data.explanation} - ${data.state}`);
                if(data.state){
                this.router.navigate(['subscribe']);
                console.log(`redirect`);
                }else{
                  alert(data.explanation);
                }
              }),
            (error)=>console.error(`ERROR ${error.message}`),
            ()=>console.log(`FIN`); 
}
}

