import { ValidUser } from './valid-user';

describe('ValidUser', () => {
  it('should create an instance', () => {
    expect(new ValidUser()).toBeTruthy();
  });
});
