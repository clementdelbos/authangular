export class InscriptionResponse {
    explanation: string;
    state:boolean;
}
