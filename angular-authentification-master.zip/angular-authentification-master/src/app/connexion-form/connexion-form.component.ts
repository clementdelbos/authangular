import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {MatDialog} from '@angular/material/dialog'
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './connexion-form.component.html',
  styleUrls: ['./connexion-form.component.css']
})
export class ConnexionFormComponent implements OnInit {

  constructor(private router: Router, private service: UserService) { }

  showSpinner=false;
  username: string;
  password: string;

  ngOnInit(): void {
  }
login1() : void {
    if(this.username == 'admin' && this.password == 'admin'){
     this.router.navigate(["user"]);
    }else {
      alert("Invalid credentials");
    }
  }
  
  login():void{
    console.log(`demande de connexion pour user ${this.username} pswd ${this.password}`);
   this.service.authenticate(this.username,this.password);
   
  }

  subscribe():void{
    console.log(`demande d'inscription, routage`);
    this.router.navigate(["subscribe"]);
   ;
  }
}
