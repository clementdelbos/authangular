export class ValidUser {

nom: string;
identifiant: string;
valid: boolean;



}
