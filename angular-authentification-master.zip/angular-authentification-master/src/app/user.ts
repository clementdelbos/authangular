export class User {
    id:number;
	identifiant:String ;
	nom:String ;
	email:String ;
	password:String ;
	digest:String ;
}
