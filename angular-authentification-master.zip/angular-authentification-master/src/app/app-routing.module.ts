import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { ConnexionFormComponent } from './connexion-form/connexion-form.component';
import { InscriptionFormComponent } from './inscription-form/inscription-form.component';


const routes: Routes = [
  { path: 'user', component: UserComponent },
  { path: 'login', component: ConnexionFormComponent },
  { path: 'subscribe', component: ConnexionFormComponent },
  {path : '', component : ConnexionFormComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
