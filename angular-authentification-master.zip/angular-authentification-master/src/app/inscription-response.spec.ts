import { InscriptionResponse } from './inscription-response';

describe('InscriptionResponse', () => {
  it('should create an instance', () => {
    expect(new InscriptionResponse()).toBeTruthy();
  });
});
