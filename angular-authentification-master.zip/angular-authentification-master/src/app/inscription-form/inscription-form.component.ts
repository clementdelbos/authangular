import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { User } from '../user';

@Component({
  selector: 'app-inscription-form',
  templateUrl: './inscription-form.component.html',
  styleUrls: ['./inscription-form.component.css']
})
export class InscriptionFormComponent implements OnInit {

  showSpinner=false;
  username:string;
  nom:string;
  email:string;
  password:string;
 

  constructor(private router: Router, private service: UserService) { }

  ngOnInit(): void {
  }


  subscribe(){
    let newUser :User = {identifiant:this.username,nom:this.nom,email:this.email,password:this.password,id:0,digest:''};
    console.log(`demande de connexion pour user ${this.username} pswd ${this.password}`);
    this.service.subscribe(newUser);
    
  }

  backToHome(){
    console.log(`demande de retour, routage vers Connexion`);
    this.router.navigate(['']);
   ;
  }
}
